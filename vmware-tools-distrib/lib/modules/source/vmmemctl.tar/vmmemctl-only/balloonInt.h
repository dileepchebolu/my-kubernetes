/*********************************************************
 * Copyright (C) 2012,2014-2016 VMware, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation version 2 and no later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *
 *********************************************************/
#ifndef BALLOONINT_H_
# define BALLOONINT_H_

#include "balloon_def.h"

/*
 * Compile-Time Options
 */

#define BALLOON_NAME                    "vmmemctl"
#define BALLOON_NAME_VERBOSE            "VMware memory control driver"

// Capabilities for Windows are defined at run-tine (see nt/vmballoon.c)
#if defined __linux__ || (defined __APPLE__ && defined __LP64__)
#define BALLOON_CAPABILITIES    (BALLOON_BASIC_CMDS|BALLOON_BATCHED_CMDS|\
                                 BALLOON_BATCHED_2M_CMDS)
#elif defined __FreeBSD__ || (defined __APPLE__ && !defined __LP64__)
#define BALLOON_CAPABILITIES    (BALLOON_BASIC_CMDS|BALLOON_BATCHED_CMDS)
#else
#define BALLOON_CAPABILITIES    BALLOON_BASIC_CMDS
#endif

#define BALLOON_RATE_ADAPT      1

#define BALLOON_DEBUG           1
#define BALLOON_DEBUG_VERBOSE   0

#define BALLOON_POLL_PERIOD             1 /* sec */
#define BALLOON_NOSLEEP_ALLOC_MAX       16384

#define BALLOON_RATE_ALLOC_MIN          512
#define BALLOON_RATE_ALLOC_MAX          2048
#define BALLOON_RATE_ALLOC_INC          16

#define BALLOON_RATE_FREE_MIN           512
#define BALLOON_RATE_FREE_MAX           16384
#define BALLOON_RATE_FREE_INC           16

/*
 * Move it to bora/public/balloon_def.h later, if needed. Note that
 * BALLOON_PAGE_ALLOC_FAILURE is an internal error code used for
 * distinguishing page allocation failures from monitor-backdoor errors.
 * We use value 1000 because all monitor-backdoor error codes are < 1000.
 */
#define BALLOON_PAGE_ALLOC_FAILURE      1000

#define BALLOON_STATS

#ifdef	BALLOON_STATS
#define	STATS_INC(stat)	(stat)++
#define	STATS_DEC(stat)	(stat)--
#else
#define	STATS_INC(stat)
#define	STATS_DEC(stat)
#endif

#define PPN_2_PA(_ppn)  ((PPN64)(_ppn) << PAGE_SHIFT)
#define PA_2_PPN(_pa)   ((_pa) >> PAGE_SHIFT)

#endif /* !BALLOONINT_H_ */
